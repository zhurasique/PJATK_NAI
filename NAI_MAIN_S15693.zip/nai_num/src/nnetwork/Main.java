package nnetwork;

import data.SetLoader;
import gui.TempPanel;

import javax.swing.*;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class Main {

    public static int EPOCH_NUM = 50;

    public static void main(String[] args) {

        List<Neuron> hiddenLayer = new ArrayList<>();
        for (int i = 0; i < 64; i++)
            hiddenLayer.add(new Neuron());
        List<Neuron> outputLayer = new ArrayList<>();
        for (int i = 0; i < 10; i++)
            outputLayer.add(new Neuron(hiddenLayer));
        List<List<List<Float>>> trainSet = null;
        try {
            trainSet = SetLoader.getSet("./optdigits.tra");
        } catch (IOException e) {
            e.printStackTrace();
        }


        for (int i = 0; i < EPOCH_NUM; i++)
            for (List<List<Float>> ls : trainSet) {
                for (int j = 0; j < 10; j++)
                    outputLayer.get(j).trainWeights(ls.get(0), ls.get(1).get(j));
                for (int j = 0; j < 64; j++)
                    hiddenLayer.get(j).trainWeights(ls.get(0));
            }

        List<List<List<Float>>> testSet = null;
        try {
            testSet = SetLoader.getSet("./optdigits.tes");
        } catch (IOException e) {
            e.printStackTrace();
        }

        int totalGuessed = 0;

        for (List<List<Float>> ls : testSet) {
            float max = -100;
            int calculated = -1;
            for (int j = 0; j < 10; j++) {
                float pred = outputLayer.get(j).predictAll(ls.get(0));
                if (pred > max) {
                    max = pred;
                    calculated = j;
                }
            }
            int expected = 0;
            for (int i = 0; i < 10; i++) {
                float value = ls.get(1).get(i);
                expected += value * i;
            }
            if (calculated == expected) totalGuessed += 1;
        }

        System.out.println("Total guessed: " + totalGuessed);
        System.out.println("Accuracy: " + totalGuessed * 100 / 1797 + "%");

        JFrame frame = new JFrame();
        TempPanel dp = new TempPanel(outputLayer);
        frame.add(dp);
        frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        frame.setVisible(true);
        frame.setLocationRelativeTo(null);
        frame.pack();

    }
}
