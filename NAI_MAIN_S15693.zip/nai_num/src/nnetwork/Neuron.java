package nnetwork;

import java.util.ArrayList;
import java.util.List;

public class Neuron {

    private static float learningRate = 0.1f;

    private float[] wages = new float[65];
    private List<Neuron> connectedNeurons;
    private float error;

    Neuron() {
        generateWages();
    }

    Neuron(List<Neuron> connectedNeurons) {
        generateWages();
        this.connectedNeurons = connectedNeurons;
    }

    private void generateWages() {
        for (int i = 0; i < wages.length; i++)
            wages[i] = Math.random() * ((int)(Math.random()*2)) % 2 == 0 ? -1f : 1f;
    }

    private float predict(List<Float> input) {
        return Unipolar.getActivation(getNet(input));
    }

    public float predictAll(List<Float> input) {
        List<Float> calculatedInput = new ArrayList<>();
        if (connectedNeurons != null) {
            for (int i = 0; i < connectedNeurons.size(); i++)
                calculatedInput.add(connectedNeurons.get(i).predict(input));
        }
        return Unipolar.getActivation(getNet(calculatedInput));
    }

    private float getNet(List<Float> input) {
        float activation = wages[0];
        for (int i = 1; i < wages.length; i++)
            activation += wages[i] * input.get(i - 1);
        return activation;
    }

    void trainWeights(List<Float> input, float expected) {
        if (connectedNeurons != null) {
            List<Float> calculatedInput = new ArrayList<>();
            for (int i = 0; i < connectedNeurons.size(); i++)
                calculatedInput.add(connectedNeurons.get(i).predict(input));

            float error = (expected - predict(calculatedInput)) * Unipolar.getDerivative(predict(calculatedInput));

            for (int i = 0; i < connectedNeurons.size(); i++)
                connectedNeurons.get(i).error += error * wages[i + 1];

            wages[0] = wages[0] + error * learningRate;
            for (int i = 1; i < wages.length; i++)
                wages[i] = wages[i] + error * learningRate * calculatedInput.get(i - 1);
        }
    }

    void trainWeights(List<Float> input) {

        if (connectedNeurons == null) {
            error *= Unipolar.getDerivative(predict(input));
            wages[0] = wages[0] + error * learningRate;
            for (int i = 1; i < wages.length; i++)
                wages[i] = wages[i] + error * learningRate * input.get(i - 1);
        }

        error = 0;

    }

}
