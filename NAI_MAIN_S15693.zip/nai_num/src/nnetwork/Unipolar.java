package nnetwork;

class Unipolar {

    static float getActivation(float net) {
        return (float) (1/(1+Math.exp(-net)));
    }

    static float getDerivative(float f) {
        return (f * (1 - f));
    }

}
