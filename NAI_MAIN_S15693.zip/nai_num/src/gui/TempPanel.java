package gui;

import nnetwork.Neuron;

import javax.swing.*;
import java.awt.GridLayout;
import java.awt.Color;
import java.util.*;

public class TempPanel extends JPanel {

    private GridPanel panel;
    List<Neuron> outputLayer;

    public TempPanel(List<Neuron> outputLayer) {
        this.outputLayer=outputLayer;
        setLayout(new BoxLayout(this, BoxLayout.PAGE_AXIS));
        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new GridLayout(1,2));
        panel = new GridPanel();
        panel.setBackground(Color.WHITE);
        mainPanel.add(panel);

        JTextArea txtResult = new JTextArea();
        txtResult.setEditable(false);
        JScrollPane jScrollPane = new JScrollPane(txtResult);
        mainPanel.add(jScrollPane);
        add(mainPanel);

        JPanel btnPanel = new JPanel();

        JButton btnReg = new JButton("Recognize");
        btnReg.addActionListener(e ->{
            List<Float> data = getData();
            float max = -100;
            int l = -1;
            for (int j = 0; j < 10; j++) {
                float pred = outputLayer.get(j).predictAll(data);
                if (pred > max) {
                    max = pred;
                    l = j;
                }
            }
            txtResult.append("Calculated number : " + l+ "\n");
        });


        JButton btnClear = new JButton("Clear");
        btnClear.addActionListener(e ->
                panel.clear()
        );

        btnPanel.add(btnReg);
        btnPanel.add(btnClear);
        add(btnPanel);
    }

    private List<Float> getData(){
        List<List<Float>> data = new ArrayList<>();
        for (int i = 0; i < 32; i++) {
            data.add(new ArrayList<>());
            for (int j = 0; j < 32; j++) {
                data.get(i).add((float)(panel.getGrid()[j][i] ? 1 : 0));
            }
        }
        List<Float> sumr = new ArrayList<>();
        for (int i = 0; i < 8; i++) {
            for (int j = 0; j < 8; j++) {
                float a = 0;
                for (int o=0; o<4; o++){
                    for (int o2=0;o2<4;o2++){
                        a+=data.get(i*4+o).get(j*4+o2);
                    }
                }
                sumr.add(a);
            }
        }
        return sumr;
    }

}
