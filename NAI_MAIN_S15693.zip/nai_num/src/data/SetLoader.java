package data;

import java.io.File;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.CharBuffer;
import java.nio.channels.FileChannel;
import java.nio.charset.Charset;
import java.nio.file.Paths;
import java.util.*;

public class SetLoader {
    static List<List<List<Float>>> trainSet;

    public static List<List<List<Float>>> getSet(String namefile) throws IOException {
        trainSet = new ArrayList<>();
        File[] filesToRead = {new File(namefile),
        };
        for (File f : filesToRead) {
            FileChannel fc = FileChannel.open(f.toPath());
            ByteBuffer bb = ByteBuffer.allocate(1024);
            StringBuffer stringBuffer = new StringBuffer();
            int numsToRead = fc.read(bb);
            while (numsToRead != -1) {
                bb.flip();
                CharBuffer cb = Charset.forName("UTF-8").decode(bb);
                stringBuffer.append(cb.toString());
                bb.clear();
                numsToRead = fc.read(bb);
            }
            String[] rows = stringBuffer.toString().split("\n");
            for (String row : rows)
                trainSet.add(getVariables(row));
        }

        return trainSet;
    }

    public static List<List<Float>> getVariables(String str) {
        List<List<Float>> result = new ArrayList<>();
        result.add(new ArrayList<>());
        result.add(new ArrayList<>());
        String inputs[] = str.split(",");
        for (int i = 0; i < 64; i++)
            result.get(0).add(Float.parseFloat(inputs[i]));
        for (int i = 0; i < 10; i++)
            result.get(1).add(Float.parseFloat(inputs[inputs.length - 1]) == i ? 1.0f : 0.0f);
        return result;
    }
}